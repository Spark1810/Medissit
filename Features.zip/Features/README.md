# Patient Helper App Suite

## Overview
The **Patient Helper App Suite** is a collection of tools designed to enhance patient experience and support. It includes a **Translation Assistant** for multilingual interactions, a **Reminder System** for medication and appointment alerts, and an **Appointment Maker** for easy scheduling. Together, these applications provide accessible, voice-activated assistance to help patients manage their health care needs.

## Features

### 1. Translation Assistant
   - **Speech Recognition**: Listens to user input via microphone.
   - **Language Detection**: Detects the language of the user’s spoken input.
   - **Translation and Response**: Provides a translated response in the detected language.
   - **Text-to-Speech**: Plays back responses in the user's language, facilitating multilingual communication.
   - **Tech Stack**: `SpeechRecognition`, `googletrans`, `gTTS`, `os`.

### 2. Reminder System
   - **Medication Reminders**: Allows patients to set reminders for taking medications.
   - **Appointment Reminders**: Schedules reminders for upcoming appointments with health providers.
   - **Custom Reminders**: Enables setting of personal reminders for health and wellness tasks.
   - **On-Screen Pop-Ups and System Notifications**: Alerts the user at specified times.
   - **Tech Stack**: `Streamlit`, `Plyer`, `datetime`, `threading`, `time`.

### 3. Appointment Maker
   - **Voice-Activated Input**: Collects patient information (name, doctor, date, time) through voice commands.
   - **Confirmation and Retry**: Confirms the details with the user and allows retrying if needed.
   - **Automatic Appointment Booking**: Stores the appointment details for future reference.
   - **Tech Stack**: `SpeechRecognition`, `pyttsx3`, `datetime`.

## File Descriptions

1. **translation.py**:
   - This script powers the **Translation Assistant**. It listens to the user, detects language, translates a response, and plays back the response in the user’s native language.

2. **remainder.py**:
   - The **Reminder System** script enables users to set reminders for various tasks like medication, appointments, or custom needs. It sends notifications and on-screen alerts at specified times.

3. **appointment_maker.py**:
   - This script manages the **Appointment Maker** functionality. It interacts with the user to collect appointment details through voice commands, confirms the details, and stores the information for easy retrieval.

## Getting Started

### Prerequisites
- **Python** 3.6+
- **Libraries**: Install required libraries using:
    ```bash
    pip install SpeechRecognition googletrans gTTS pyttsx3 plyer streamlit
    ```

### Running Each Module
1. **Translation Assistant**:
    ```bash
    python translation.py
    ```
    - Provides a voice-activated translation experience, useful for multilingual environments.

2. **Reminder System**:
    ```bash
    streamlit run remainder.py
    ```
    - Open Streamlit in a browser and set medication, appointment, or custom reminders. Notifications appear as pop-ups on your screen.

3. **Appointment Maker**:
    ```bash
    python appointment_maker.py
    ```
    - Walks the user through an interactive voice-guided appointment booking process.

## Usage Scenarios
1. **Translation Assistant**:
   - For patients or caretakers who prefer instructions or interactions in a specific language.
   
2. **Reminder System**:
   - To help patients remember important health tasks like medication or appointments.
   
3. **Appointment Maker**:
   - To assist in scheduling appointments through a voice-guided, user-friendly process.

## License
This project is licensed under the MIT License.

## Acknowledgments
This suite uses open-source libraries to improve healthcare accessibility. Thanks to the developers of `SpeechRecognition`, `googletrans`, `gTTS`, `pyttsx3`, and `Streamlit` for their contributions.
