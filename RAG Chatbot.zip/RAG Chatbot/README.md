# RAG LLM Chatbot

This is the code to a chatbot that uses the NIH ODS Fact Sheets (https://ods.od.nih.gov/api/) to generate grounded answers.

The project uses LangChain with a technique called Retrieval Augmented Generation (RAG) to provide a Large Language Model (LLM) with useful context to base results on.

## Overview
This project is a chatbot application that uses Streamlit, LangChain, and Chroma to retrieve and respond to user queries based on information from the NIH ODS Fact Sheets. It employs a retrieval-augmented generation (RAG) approach to ensure responses are medically grounded and accurate, drawing on NIH's reliable database.

## Features
- **Chat Interface**: User-friendly chat interface built with Streamlit.
- **Data Ingestion and Chunking**: Utilizes `chunking.py` to retrieve, process, and store NIH data for efficient querying.
- **RAG Model**: Combines OpenAI’s GPT-3.5 model and NIH fact sheets to produce concise, factual responses.
- **Data Source**: Fetches information directly from the [NIH ODS Fact Sheets API](https://ods.od.nih.gov/api/).

## Technologies Used
- **Streamlit**: For creating the interactive chat interface.
- **LangChain**: To manage prompt design, retrieval chains, and document processing.
- **Chroma**: For storing and retrieving vector embeddings.
- **OpenAI GPT-3.5**: Generates natural language responses based on NIH data.

## Setup Instructions

### Prerequisites
- Python 3.7 or higher
- `pip` or `conda` for package management
- OpenAI API key

### Installation
1. Clone the repository to your local machine:
    ```bash
    git clone <repository-url>
    cd <repository-directory>
    ```

2. Install the required dependencies:
    ```bash
    pip install -r requirements.txt
    ```

3. Ensure you have an OpenAI API key.

### Running the Application
1. **Run `chunking.py`** to load, chunk, and store data in the Chroma vector database:
    ```bash
    python chunking.py
    ```

2. **Start the chatbot** by running the Streamlit app:
    ```bash
    streamlit run app.py
    ```

### Usage
- After launching the app, enter queries in the chat interface for answers sourced from NIH ODS Fact Sheets.
- The bot provides concise responses (up to three sentences) and indicates when it does not know the answer.

## Code Structure

### `app.py`
- **Vectorstore Setup**: Initializes Chroma with OpenAI embeddings, storing the NIH fact sheets for retrieval.
- **RAG Chain Setup**: Combines retrieved data with GPT-3.5 for enhanced answer generation.
- **Prompt Design**: Instructs the model to answer based on NIH data in a friendly, clinician tone.

### `chunking.py`
The `chunking.py` script is responsible for data retrieval and processing:
1. **Step 1: NIH API Retrieval**  
   - Connects to the NIH ODS Fact Sheets API.
   - Extracts relevant links, excluding Spanish versions.

2. **Step 2: Retrieve, Chunk, and Index Web Pages**
   - Uses `WebBaseLoader` from `langchain_community` to fetch content from NIH links.
   - Chunks content into smaller, manageable pieces with `RecursiveCharacterTextSplitter` to optimize storage and retrieval.

3. **Step 3: Save to Disk**  
   - Stores chunks as embeddings in Chroma for efficient retrieval during chatbot interaction.

## Example Query
If you type a query like:
```
What are the health benefits of Vitamin D?
```
The chatbot will retrieve relevant documents from the NIH ODS Fact Sheets and generate a medically grounded response, citing sources.

## Sources
The sources for the answers are derived from the NIH ODS Fact Sheets API and will be displayed at the end of the chatbot's response.

---

## License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

### References

- [Quickstart for Question Answering](https://python.langchain.com/v0.1/docs/use_cases/question_answering/quickstart/)
- [Use OpenAI Embeddings with Chroma](https://python.langchain.com/v0.2/docs/integrations/vectorstores/chroma/#use-openai-embeddings)
- [How to Use QA Sources](https://python.langchain.com/v0.2/docs/how_to/qa_sources/)
- [Chroma Telemetry Documentation](https://docs.trychroma.com/telemetry)
